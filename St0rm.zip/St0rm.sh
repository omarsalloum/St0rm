#! /bin/bash
# Mitmf ( man in middle attack script )withe SSLStrip 
# Date: 07/05/2016
sleep 0.25
echo "$( tput setaf 6) 

               ######   ##    ##
              ##    ##   ##  ##
              ##          ####
               ######      ##
                    ##     ##
              ##    ##     ##
               ######      ##
            $( tput setaf 3)Coded By Syrian St0rm$(tput sgr0)
                 $( tput setaf 6)d5@live.se$(tput sgr0)
$(tput sgr0) "
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
sleep 0.05
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)+$(tput sgr0)$( tput setaf 1)]$(tput sgr0) $( tput setaf 2)$(tput sgr0) $(tput bold)Man In Middle Attack Script$(tput sgr0) $( tput setaf 2)$(tput sgr0) $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)+$(tput sgr0)$( tput setaf 1)]$(tput sgr0)"
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
sleep 0.05
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)+$(tput sgr0)$( tput setaf 1)]$(tput sgr0) tested on $( tput setaf 2):$(tput sgr0) $(tput bold)Kali Linux 2.0 $(tput sgr0)$( tput setaf 1)[$(tput sgr0)$( tput setaf 2)+$(tput sgr0)$( tput setaf 1)]$(tput sgr0)"
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
sleep 0.05
echo " "
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)+$(tput sgr0)$( tput setaf 1)]$(tput sgr0) choose a number below :"
sleep 0.05
echo ""
echo "  $( tput setaf 3)1$(tput sgr0)$( tput setaf 1).$(tput sgr0) M.I.T.M  $( tput setaf 2)[$(tput sgr0) Listens To All Network Traffic $( tput setaf 2)]$(tput sgr0)" 
sleep 0.05
echo ""
echo "  $( tput setaf 3)2$(tput sgr0)$( tput setaf 1).$(tput sgr0) Driftnet $( tput setaf 2)[$(tput sgr0) Watch Network Traffic And Picks out Images $( tput setaf 2)]$(tput sgr0) "
sleep 0.05
echo "" 
echo "  $( tput setaf 3)3$(tput sgr0)$( tput setaf 1).$(tput sgr0) SSLStrip $( tput setaf 2)[$(tput sgr0) To Redirect Traffic To HTTP $( tput setaf 2)]$(tput sgr0) "
echo ""
sleep 0.05
echo "  $( tput setaf 3)4$(tput sgr0)$( tput setaf 1).$(tput sgr0) Exit" 
read number
case "$number" in 
'1') 
tools/1.sh;;
'2')
tools/2.sh;;
'3')
tools/3.sh;;
'4')
exit&clear
esac 

