#! /bin/bash
# Date: 07/05/2016
sleep 0.25
echo "$( tput setaf 6) 

               ######   ##    ##
              ##    ##   ##  ##
              ##          ####
               ######      ##
                    ##     ##
              ##    ##     ##
               ######      ##
            $( tput setaf 3)Coded By Syrian St0rm$(tput sgr0)
                 $( tput setaf 6)d5@live.se$(tput sgr0)
$(tput sgr0) "
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
chmod +x St0rm.sh
echo "$( tput setaf 2)Downloading the required files$(tput sgr0)" 
echo " "
apt-get install mitmf
sleep 0.05
echo " " 
echo "$( tput setaf 2)MITMf attacks installed Successfully$(tput sgr0) "
echo ""  
apt-get install sslsniff
sleep 0.05
echo " "
echo "$( tput setaf 2)SSLSniff installed Successfully$(tput sgr0) "
echo " "
echo "$( tput setaf 2)   _-=-_ Done .. enjoy _-=-_$(tput sgr0)" 

echo "" 
echo " $( tput setaf 3)All Files installed SuccessFully $(tput sgr0)" 
echo  "$( tput setaf 6)
.####...######...####...#####...##...##.
##........##....##..##..##..##..###.###.
.####.....##....##..##..#####...##.#.##.
...##....##....##..##..##..##..##...##.
####.....##.....####...##..##..##...##.
.......................................
$(tput sgr0)"
